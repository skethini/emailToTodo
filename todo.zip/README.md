# emailToTodo
Given text from an email in your inbox, this program will classify sentences as requests, questions, or statements. It will reformat the sentences using NLP and return a to-do list and a list of questions you'll need to answer in your email reply.
